import Paciente from './Paciente.js';
import PacienteConvenio from './PacienteConvenio.js';

// Classe Utilitária para manipulação do DOM
class ManipuladorDOM {
    constructor(seletorTabelaBody) {
        this.tabelaBody = document.querySelector(seletorTabelaBody);
    }

    limparTabela() {
        this.tabelaBody.innerHTML = '';
    }

    renderizarLinha(paciente) {
        const tr = document.createElement('tr');
        const imcFormatado = paciente.calcularIMC().toFixed(2);
        const classificacao = paciente.definirClassificacao();

        const textoTipo = paciente instanceof PacienteConvenio
            ? `Convênio (${paciente.carteirinha})`
            : 'Particular';

        tr.innerHTML = `
            <td>${paciente.nome}</td>
            <td>${textoTipo}</td>
            <td>${paciente.cidade}</td>
            <td>${paciente.altura.toFixed(2)}</td>
            <td>${paciente.peso.toFixed(1)}</td>
            <td>${imcFormatado}</td>
            <td>${classificacao}</td>
        `;

        this.tabelaBody.appendChild(tr);
    }
}

// Classe Controladora da Aplicação
class PainelApp {
    constructor() {
        this.pacientes = [];
        this.dom = new ManipuladorDOM('#tabela-pacientes');
        this.form = document.querySelector('#form-paciente');
        this.selectTipo = document.querySelector('#tipo');
        this.inputCarteirinha = document.querySelector('#carteirinha');
        this.inputCep = document.querySelector('#cep');
        this.inputCidade = document.querySelector('#cidade');

        this.iniciarEventos();
    }

    iniciarEventos() {
        // Evento de alteração do tipo de atendimento
        this.selectTipo.addEventListener('change', () => {
            if (this.selectTipo.value === 'convenio') {
                this.inputCarteirinha.disabled = false;
                this.inputCarteirinha.required = true;
            } else {
                this.inputCarteirinha.disabled = true;
                this.inputCarteirinha.required = false;
                this.inputCarteirinha.value = '';
            }
        });

        // Evento blur para consulta automática do CEP via API ViaCEP
        this.inputCep.addEventListener('blur', () => {
            this.buscarCep();
        });

        // Evento submit do formulário
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.adicionarPaciente();
        });
    }

    async buscarCep() {
        const cepLimpo = this.inputCep.value.replace(/\D/g, '');

        if (cepLimpo === '') {
            this.inputCidade.value = '';
            return;
        }

        // Validação: CEP deve conter exatamente 8 dígitos numéricos
        if (cepLimpo.length !== 8) {
            alert('Por favor, digite um CEP válido com 8 dígitos numéricos.');
            this.inputCep.value = '';
            this.inputCidade.value = '';
            return;
        }

        try {
            const resposta = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
            const dados = await resposta.json();

            if (dados.erro) {
                alert('CEP não encontrado!');
                this.inputCep.value = '';
                this.inputCidade.value = '';
            } else {
                this.inputCidade.value = `${dados.localidade} / ${dados.uf}`;
            }
        } catch (erro) {
            alert('Erro ao buscar o CEP. Verifique a conexão com a internet.');
            console.error(erro);
        }
    }

    adicionarPaciente() {
        const nome = document.querySelector('#nome').value.trim();
        const tipo = this.selectTipo.value;
        const carteirinha = this.inputCarteirinha.value.trim();
        const cidade = this.inputCidade.value.trim();
        const altura = parseFloat(document.querySelector('#altura').value);
        const peso = parseFloat(document.querySelector('#peso').value);

        // Validação de campos numéricos positivos
        if (isNaN(altura) || altura <= 0 || isNaN(peso) || peso <= 0) {
            alert('Por favor, insira valores válidos e positivos para peso e altura.');
            return;
        }

        if (!cidade) {
            alert('Por favor, preencha um CEP válido para carregar a Cidade/UF.');
            return;
        }

        let novoPaciente;

        if (tipo === 'convenio') {
            if (!carteirinha) {
                alert('Por favor, insira o número da carteirinha do convênio.');
                return;
            }
            novoPaciente = new PacienteConvenio(nome, altura, peso, cidade, carteirinha);
        } else {
            novoPaciente = new Paciente(nome, altura, peso, cidade);
        }

        this.pacientes.push(novoPaciente);
        this.renderizarPainel();
        
        // Limpar e focar no campo Nome
        this.form.reset();
        this.inputCarteirinha.disabled = true;
        this.inputCarteirinha.required = false;
        document.querySelector('#nome').focus();
    }

    renderizarPainel() {
        this.dom.limparTabela();
        this.pacientes.forEach((paciente) => {
            this.dom.renderizarLinha(paciente);
        });
    }
}

// Inicialização da Aplicação
document.addEventListener('DOMContentLoaded', () => {
    new PainelApp();
});