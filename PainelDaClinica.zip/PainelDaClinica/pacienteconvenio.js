import Paciente from './Paciente.js';

export default class PacienteConvenio extends Paciente {
    #carteirinha;

    constructor(nome = '', altura = 0, peso = 0, cidade = '', carteirinha = '') {
        super(nome, altura, peso, cidade);
        this.#carteirinha = carteirinha;
    }

    get carteirinha() { return this.#carteirinha; }
    set carteirinha(carteirinha) { this.#carteirinha = carteirinha; }
}