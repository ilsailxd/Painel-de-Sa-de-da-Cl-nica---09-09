export default class Paciente {
    #nome;
    #altura;
    #peso;
    #cidade;

    constructor(nome = '', altura = 0, peso = 0, cidade = '') {
        this.#nome = nome;
        this.#altura = parseFloat(altura);
        this.#peso = parseFloat(peso);
        this.#cidade = cidade;
    }

    // Getters
    get nome() { return this.#nome; }
    get altura() { return this.#altura; }
    get peso() { return this.#peso; }
    get cidade() { return this.#cidade; }

    // Setters
    set nome(nome) { this.#nome = nome; }
    set altura(altura) { this.#altura = parseFloat(altura); }
    set peso(peso) { this.#peso = parseFloat(peso); }
    set cidade(cidade) { this.#cidade = cidade; }

    calcularIMC() {
        if (this.#altura <= 0) return 0;
        return this.#peso / (this.#altura * this.#altura);
    }

    definirClassificacao() {
        const imc = this.calcularIMC();
        if (imc < 18.5) {
            return 'Abaixo do peso';
        } else if (imc >= 18.5 && imc <= 24.9) {
            return 'Peso normal';
        } else if (imc >= 25.0 && imc <= 29.9) {
            return 'Sobrepeso';
        } else if (imc >= 30.0 && imc <= 34.9) {
            return 'Obesidade Grau I';
        } else if (imc >= 35.0 && imc <= 39.9) {
            return 'Obesidade Grau II';
        } else {
            return 'Obesidade Grau III';
        }
    }
}