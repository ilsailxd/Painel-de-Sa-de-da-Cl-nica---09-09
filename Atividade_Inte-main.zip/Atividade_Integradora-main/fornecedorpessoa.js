import Fornecedor from './fornecedor.js'

class FornecedorPessoa extends Fornecedor{
    #rg
    #cpf

    constructor(nome = "Sem nome", fone ="SIX SEVEN",rg = "", cpf ="" ){
        super(nome,fone);
        this.#rg = rg;
        this.#cpf =cpf;
    }
    set_rg(){
        this.#rg=rg
    }
    set_cpf(){
        this.#cpf = this.#cpf
    }
    get_rg(){
        this.#rg= rg 
    }
    get_cpf(){
        this.#cpf = cpf 
    }
}
export default FornecedorPessoa 