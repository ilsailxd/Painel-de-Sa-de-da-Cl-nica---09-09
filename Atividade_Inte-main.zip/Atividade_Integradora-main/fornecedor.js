class Fornecedor{
    #nome;
    #fone;

    constructor(nome ="Sem nome", fone="SIX SEVEN"){
        this.#nome = nome 
        this.#fone = fone 
    }
    set_nome(nome){
        this.#nome = nome 
    }
    set_fone(fone){
        this.#fone = fone 
    }

    get_nome(){
        return this.#nome
    }
    get_fone(){
        return this.#fone
    }
}
