import FornecedorPessoa from "./fornecedorpessoa";
import Fornecedor from "./fornecedor";

const fornecedor = new Fornecedor("Pedro Henrique", "Six Seven", "rg","cpf");

console.log(`Dados do Fornecedor:
    Nome: ${objFornecedor.get_nome()};
    Fone: ${objFornecedor.get_fone()};
     `);

const objFornecedoPessoa = new FornecedorPessoa("Marina", "SIX EIGHT", "rg", "cpf")

console.log(`Dados do Fornecedor Pessoa 
    Nome: ${objFornecedorPessoa.get_nome()};
    Fone: ${objFornecedorPessoa.get_fone()};
    RG: ${objFornecedorPessoa.get_rg()};
    Cpf: ${objFornecedorPessoa.get_cpf()};
    `)